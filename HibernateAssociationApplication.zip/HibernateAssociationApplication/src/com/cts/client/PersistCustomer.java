package com.cts.client;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cts.entities.Customer;
import com.cts.entities.Item;
import com.cts.entities.Order;

public class PersistCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Item> items1=new ArrayList<Item>();
		Item item1a=new Item();
		item1a.setItemCode("ITEM01");
		item1a.setItemDescription("XYZ1");
		item1a.setItemPrice(200);
		item1a.setItemQuantity(3);
		
		Item item1b=new Item();
		item1b.setItemCode("ITEM02");
		item1b.setItemDescription("ABC");
		item1b.setItemPrice(1200);
		item1b.setItemQuantity(2);
		
		items1.add(item1a);
		items1.add(item1b);
		
		Order order1=new Order();
		order1.setOrderCode("ORD01");
		order1.setOrderDescription("ORDER 01");
		order1.setItems(items1);
		
		List<Item> items2=new ArrayList<Item>();
		Item item2a=new Item();
		item2a.setItemCode("ITEM02a");
		item2a.setItemDescription("XYZ2a");
		item2a.setItemPrice(2300);
		item2a.setItemQuantity(4);
		
		Item item2b=new Item();
		item2b.setItemCode("ITEM02b");
		item2b.setItemDescription("XYZ2b");
		item2b.setItemPrice(2400);
		item2b.setItemQuantity(2);
		
		Item item2c=new Item();
		
		item2c.setItemCode("ITEM02c");
		item2c.setItemDescription("XYZ2c");
		item2c.setItemPrice(7300);
		item2c.setItemQuantity(1);
		
		items2.add(item2a);
		items2.add(item2b);
		items2.add(item2c);
		
		Order order2=new Order();
		order2.setOrderCode("ORD02");
		order2.setOrderDescription("ORDER 02");
		order2.setItems(items2);
		
		List<Order> orders=new ArrayList<Order>();
		orders.add(order1);
		orders.add(order2);
		
		Customer customer=new Customer();
		customer.setCustomerId(1);
		customer.setCustomerName("Sabbir");
		customer.setCustomerAddress("Some Address");
		customer.setCustomerPhoneNumber("123456");
		customer.setOrders(orders);
		
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction et=manager.getTransaction();
		et.begin();
		manager.persist(customer);
		et.commit();
		manager.close();
		
				
		
		
		
		
		
		
		
	}

}
