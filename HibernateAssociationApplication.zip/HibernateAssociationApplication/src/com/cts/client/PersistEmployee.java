package com.cts.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cts.entities.Employee;
import com.cts.entities.Project;

public class PersistEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Project project=new Project();
		project.setProjectId(1);
		project.setProjectName("ABN");
		project.setClientName("XYZ");
		
		Employee employee=new Employee();
		employee.setEmpName("Sabbir");
		employee.setEmpDesignation("Trainer");
		employee.setEmpSalary(45000);
		employee.setProject(project);
		
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
		EntityManager manager=factory.createEntityManager();
		EntityTransaction et=manager.getTransaction();
		et.begin();
		manager.persist(employee);
		et.commit();
		manager.close();
		
		
		
	}

}
