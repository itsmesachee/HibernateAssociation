package com.cts.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cts.entities.Customer;

public class RetrieveCustomer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
		EntityManager manager=factory.createEntityManager();
		Query query=manager.createQuery("select o from Customer o");
		Customer customer=(Customer)query.getSingleResult();
		System.out.println(customer);
		manager.close();

	}

}
