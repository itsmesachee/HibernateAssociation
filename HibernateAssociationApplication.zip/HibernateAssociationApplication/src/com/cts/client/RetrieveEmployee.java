package com.cts.client;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cts.entities.Employee;
import com.cts.entities.Project;

public class RetrieveEmployee {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA");
		EntityManager manager=factory.createEntityManager();
		Query query=manager.createQuery("select o From Employee o where o.empId=?1");
		query.setParameter(1, 50);
		Employee employee=(Employee)query.getSingleResult();
		System.out.println(employee);
		
		Project project=employee.getProject();
		System.out.println(project);
		
		

	}

}
