package com.cts.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="ItemsTable")
public class Item implements Serializable {
	
	@Id
	@Column(name="item_code")
	private String itemCode;
	
	@Column(name="item_description")
	private String itemDescription;
	
	@Column(name="item_quantity")
	private int itemQuantity;
	
	@Column(name="item_price")
	private double itemPrice;

	public String getItemCode() {
		return itemCode;
	}

	public void setItemCode(String itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemDescription() {
		return itemDescription;
	}

	public void setItemDescription(String itemDescription) {
		this.itemDescription = itemDescription;
	}

	public int getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(int itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((itemCode == null) ? 0 : itemCode.hashCode());
		result = prime * result
				+ ((itemDescription == null) ? 0 : itemDescription.hashCode());
		long temp;
		temp = Double.doubleToLongBits(itemPrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + itemQuantity;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Item other = (Item) obj;
		if (itemCode == null) {
			if (other.itemCode != null)
				return false;
		} else if (!itemCode.equals(other.itemCode))
			return false;
		if (itemDescription == null) {
			if (other.itemDescription != null)
				return false;
		} else if (!itemDescription.equals(other.itemDescription))
			return false;
		if (Double.doubleToLongBits(itemPrice) != Double
				.doubleToLongBits(other.itemPrice))
			return false;
		if (itemQuantity != other.itemQuantity)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Item [itemCode=" + itemCode + ", itemDescription="
				+ itemDescription + ", itemQuantity=" + itemQuantity
				+ ", itemPrice=" + itemPrice + "]";
	}
	
	
	
	
	
	
	

}
